package com.example.demo;

import org.springframework.web.bind.annotation.*;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*") // This allows your HTML file to connect
public class AuthController {
    private static final String FILE_NAME = "users.txt";
    private HashMap<String, String> database = new HashMap<>();

    public AuthController() {
        loadUsersFromFile();
    }

    @PostMapping("/signup")
    public String signup(@RequestBody Map<String, String> payload) {
        String user = payload.get("username");
        String pass = payload.get("password");

        if (database.containsKey(user)) return "User already exists!";

        database.put(user, pass);
        saveUserToFile(user, pass);
        return "Signup successful!";
    }

    @PostMapping("/login")
    public String login(@RequestBody Map<String, String> payload) {
        String user = payload.get("username");
        String pass = payload.get("password");

        if (database.containsKey(user) && database.get(user).equals(pass)) {
            return "Access Granted!";
        }
        return "Access Denied!";
    }

    private void saveUserToFile(String user, String pass) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME, true))) {
            writer.write(user + ":" + pass + "\n");
        } catch (IOException e) { e.printStackTrace(); }
    }

    private void loadUsersFromFile() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return;
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts.length == 2) database.put(parts[0], parts[1]);
            }
        } catch (IOException e) { e.printStackTrace(); }
    }
}